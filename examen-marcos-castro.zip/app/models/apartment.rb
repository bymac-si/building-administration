class Apartment < ApplicationRecord
  belongs_to :building
end
